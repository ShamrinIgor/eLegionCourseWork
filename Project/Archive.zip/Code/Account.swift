import Foundation

struct Account: Codable {
    var login: String
    var password: String
}
